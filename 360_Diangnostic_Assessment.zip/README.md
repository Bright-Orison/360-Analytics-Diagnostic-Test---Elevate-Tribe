# Data Analytics Program — Diagnostic Placement Test

An interactive, self-contained diagnostic assessment used to evaluate incoming
students (ages 10–20) before starting the Data Analytics training program
(Excel → SQL → Python → Power BI). The test measures baseline numeracy/logic,
digital literacy, and actual working knowledge of each tool in the stack, plus
a self-reported confidence rating, so the instructor can decide **where each
student (and the cohort as a whole) should start**.

## 🎯 Purpose
- Diagnose current skill level of each student before Day 1.
- Compare **self-rated confidence** vs **actual demonstrated skill** per stack.
- Generate an automatic, evidence-based **per-tool skill tier** (Excel / SQL /
  Python / Power BI) so you know exactly where each student stands in each
  tool — not just one blunt "start here" verdict.
- Produce a clean, printable report (Save as PDF) **and** an automatically
  collected spreadsheet of every student's results, ready for your review.

## ✅ Completed Features
- **60-question diagnostic bank** (single correct answer each, manually
  verified), grouped into 7 sections:
  1. Foundational Math & Logic (10)
  2. Digital & Data Literacy (5)
  3. Microsoft Excel (10)
  4. SQL / Databases (10)
  5. Python Programming (10)
  6. Power BI & Data Visualization (10)
  7. Statistics & Data Interpretation (5)
- **Self-assessment (ungraded)** confidence sliders for Excel, SQL, Python,
  Power BI, and Math/Statistics — captured before the timer starts.
- **Student info capture**: name, age, email, country/location, grade/school level.
- **Strict 60-minute countdown timer** starting only when the student clicks
  "Begin Timed Test." Visual warnings at 5 minutes and 1 minute remaining.
  Auto-submits the test the instant time runs out.
- **No answer leakage during the test** — students only see whether an answer
  is right/wrong, and their score, **after** they submit the whole test.
- **Section-by-section navigation** with a question-jump grid, answered/unanswered
  indicators, and a pre-submit review screen showing unanswered questions per section.
- **Automatic scoring** — overall score, per-section score & percentage.
- **Charts** (Chart.js): score by section, and self-rated confidence vs. actual
  score for the 4 core tools.
- **Full answer review** after submission: every question, the student's answer,
  the correct answer, and a ✅/❌ indicator (with short explanations).
- **Per-tool skill tiers**: Excel, SQL, Python and Power BI are each judged
  **independently** on a 4-tier scale — Mastery (≥85%), Proficient (65–84%),
  Developing (40–64%), Beginner (<40%) — with a plain-English action for each
  tier (e.g. "skip fundamentals," "fast-track refresher," "full module"). A
  high score in one tool never implies anything about another tool.
- **Suggested cohort starting focus**: in addition to the per-tool tiers, the
  engine surfaces one suggested *primary teaching focus* — the first tool (in
  Excel → SQL → Python → Power BI order) below the 65% proficiency bar — plus
  notes on foundational math/digital-literacy gaps and age-based pacing. This
  is a cohort-pacing suggestion, **not** a verdict that earlier tools are
  "fully mastered" — always check the per-tool tier table too.
- **Automatic results collection** — two independent, optional methods (see
  below): Google Sheets (recommended for GitHub Pages/Netlify/etc.) and this
  platform's built-in Table API (if hosted here). Either, both, or neither can
  be active — the "Print / Save as PDF" export always works as a guaranteed
  fallback regardless.
- **Instructor Dashboard (`admin.html`)** — only relevant if hosted on this
  platform (see below); reads the built-in Table API and shows cohort stats,
  charts, a sortable/searchable table, and CSV export.
- **Local autosave** (browser `localStorage`) — if the page is accidentally
  refreshed/closed, the student's progress and remaining time are restored.
- **Print / Save as PDF button** with dedicated print stylesheet (hides timer/nav
  controls, formats the report cleanly for sharing with the professor).
- Fully responsive, mobile/tablet-friendly layout (Tailwind CSS).

## 🌐 Entry Points
- `index.html` — the diagnostic test itself (no query parameters needed).
  Screen flow: **Welcome → Student Info & Self-Assessment (untimed) → Timed
  Test (7 sections) → Review & Submit → Results & Printable Report**.
- `admin.html` — instructor dashboard for results collected via **this
  platform's Table API only** (not used if you host on GitHub Pages/Netlify —
  see below). Not linked from student-facing pages; treat the URL as unlisted,
  not secure (no login is built in).

---

## 🚀 Recommended Hosting: GitHub Pages + Google Sheets

Since you want a clean URL (no platform branding) and want to own your data in
your own GitHub account, this is the setup we recommend and have built in:

```
Students → open your GitHub Pages link → complete assessment → Submit
                                                   ↓
                                    Sent directly to your Google Sheet
                                    (via a small Google Apps Script)
```

**Why this combo:** GitHub Pages is free static hosting with a clean URL
(optionally your own custom domain), and Google Sheets/Apps Script gives you
a zero-cost, no-login-required backend that any static site can call — so it
keeps working no matter where you host the HTML files.

### One-time setup (~10 minutes)

**Step 1 — Create the Google Sheet + Apps Script backend**
1. Go to sheets.google.com and create a new spreadsheet (e.g. "Diagnostic Test Results").
2. Extensions → Apps Script.
3. Delete the placeholder code and paste in the **entire contents** of
   `google-apps-script/Code.gs` from this project.
4. Save the project.
5. Deploy → New deployment → gear icon → **Web app**.
   - Execute as: **Me**
   - Who has access: **Anyone** (must be "Anyone", not "Anyone with a Google account")
   - Click Deploy, then authorize the script when prompted (it's your own
     script, so the "unsafe" warning is expected and safe to proceed through).
6. Copy the **Web app URL** (ends in `/exec`).

Full step-by-step instructions with extra detail are written as comments at
the top of `google-apps-script/Code.gs` — follow those exactly.

**Step 2 — Point the site at your Google Sheet**
1. Open `js/config.js` in this project.
2. Set `GOOGLE_SCRIPT_URL` to the Web app URL you copied.
3. Save.

**Step 3 — Push to your own GitHub repo & enable Pages**
1. Download/export this project's files (all of `index.html`, `admin.html`,
   `css/`, `js/`, `google-apps-script/`, `README.md`).
2. Create a new repository in your GitHub account and upload these files
   (via `git push` or GitHub's "Add file → Upload files" web UI — no coding
   required for the upload itself).
3. In the repo, go to **Settings → Pages**, set the source branch (usually
   `main`) and folder (`/root`), and save. GitHub will give you a URL like
   `https://your-username.github.io/your-repo-name/`.
4. (Optional) Under Settings → Pages → Custom domain, attach your own domain
   if you have one, for a fully branded URL.

**Step 4 — Test it end-to-end**
1. Open your GitHub Pages URL, complete the test yourself as a test student.
2. Submit, and check your Google Sheet — a new row should appear within a
   few seconds, with all scores, tiers, and answers.
3. Submitting again with the **same email** updates that same row instead of
   creating a duplicate (see "Data Model" below).

Once this is done, share the GitHub Pages link with your students — no
platform branding, you own the repo, and every submission lands directly in
a spreadsheet you control.

### Netlify / Vercel / Cloudflare Pages — also supported
The exact same `GOOGLE_SCRIPT_URL` setup works if you'd rather drag-and-drop
this folder into Netlify, or deploy via Vercel/Cloudflare Pages instead of
GitHub Pages — all of them are plain static hosts, so no code changes are
needed. Pick whichever you find easiest to manage.

---

## 🖥️ Running Locally
`index.html` is plain HTML/CSS/JS and works if you simply open it in a
browser from a downloaded folder, or host it on any static server. As long as
`GOOGLE_SCRIPT_URL` is set in `js/config.js`, the Google Sheets submission
will also work from a local file — Google Apps Script Web Apps accept
requests from anywhere, including `file://` pages. The only thing that will
**not** work outside of this platform is the built-in Table API / `admin.html`
combo, since that specific backend is tied to this platform's publish
infrastructure.

---

## 🗂️ Data Model
Client-side state lives in browser memory + `localStorage` under the key
`dap_diagnostic_v1`:
```js
{
  studentInfo: { name, age, email, location, grade },
  selfAssessment: { excel, sql, python, powerbi, stats }, // 0–4 each
  answers: { 1: 2, 2: 0, ... },                            // question id -> selected option index
  endTime: 1730000000000,                                  // ms epoch, timer end
  screen: "test" | "review" | "results",
  currentSectionIndex: 0
}
```

On submission, the same result data is also sent to whichever backend(s) are
configured:

**Google Sheet tab `Responses`** (via `google-apps-script/Code.gs`) — one row
per student, columns:
`submitted_at, student_name, student_age, student_email, student_location,
student_grade, total_correct, overall_pct, foundation_pct, digital_pct,
excel_pct, sql_pct, python_pct, powerbi_pct, stats_pct, excel_tier, sql_tier,
python_tier, powerbi_tier, self_excel, self_sql, self_python, self_powerbi,
self_stats, answers_json`.
Re-submitting with the same email **updates** that student's existing row
instead of creating a duplicate.

**Table `diagnostic_results`** (this platform's Table API, only relevant if
hosted here) — identical fields, read by `admin.html` for the built-in
dashboard (cohort stats, charts, sortable table, CSV export). This path does
**not** de-duplicate by email — if a student submits twice, sort `admin.html`
by "Submitted" and use the most recent row.

---

## 🚫 Not Yet Implemented
- Authentication/access control on `admin.html` — anyone with the URL can
  view it (only relevant if you keep using this platform's Table API path).
  Not linked from student-facing pages, but treat the link as "unlisted," not
  secure. If you go the GitHub Pages + Google Sheets route instead, your data
  lives in your own private Google Sheet, which is naturally access-controlled
  by your Google account sharing settings — generally the safer option.
- Question randomization / anti-cheating measures (e.g., shuffled answer
  order, tab-switch detection) — not included since this is a low-stakes
  diagnostic.
- Multi-language support (currently English only).
- Adaptive difficulty (test is fixed-form, not computer-adaptive).
- De-duplication by email is only implemented for the Google Sheets path (see
  Data Model above), not the platform Table API path.

## 🔭 Recommended Next Steps
1. Follow the "Recommended Hosting: GitHub Pages + Google Sheets" steps above
   before Monday, and do one full end-to-end test submission yourself first.
2. Pilot the test with a handful of students to confirm the 60-minute window
   and difficulty curve feel right for the age range.
3. After the first cohort, review common wrong answers per section (query
   `answers_json` in the Sheet) to refine which questions are mis-calibrated
   (too easy/too hard) for this age range.
4. Consider adding a short open-ended "what do you want to build with data?"
   motivational question in a follow-up Google Form — great for cohort
   grouping, not for scoring.

## 🧪 How to Use (for the professor)
1. Complete the "Recommended Hosting" setup above (Google Sheet + Apps
   Script + GitHub Pages) so results land in your spreadsheet automatically.
2. Share the GitHub Pages (or Netlify/Vercel) link with all students before
   Monday's session.
3. Ask them to complete it in one sitting (60 minutes, timed automatically).
4. On submission, results are sent to your Google Sheet automatically — but
   also ask each student to click **"Print / Save as PDF"** as a backup, in
   case of any connectivity issues.
5. Open your Google Sheet any time to see every submission, sort/filter by
   any column, or paste the data into Excel/Power BI for your own analysis
   (fittingly, using the very tools you're teaching!).
6. Use each student's **Per-Tool Skill Tier** (Mastery / Proficient /
   Developing / Beginner per tool) plus the **Suggested Cohort Starting
   Focus** on their results page/PDF to place students and decide the
   cohort's starting stack. Remember: a high score in one tool does not imply
   mastery of another — check all four tiers.

## 🛠️ Tech Stack
- HTML5 + Tailwind CSS (CDN) for layout/styling.
- Vanilla JavaScript (no framework) for logic, timer, scoring, recommendation engine.
- Chart.js (CDN) for score visualizations.
- Font Awesome (CDN) for icons.
- Google Apps Script + Google Sheets for free, portable response collection
  (works on any static host — GitHub Pages, Netlify, Vercel, Cloudflare Pages).
- Optional: this platform's built-in RESTful Table API + `admin.html`
  dashboard, if you choose to keep the site hosted here instead.
- No server-side code you have to run yourself, no authentication system, no
  paid services required.
