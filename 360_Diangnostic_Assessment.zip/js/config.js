/* ==========================================================================
   Data Analytics Program — Diagnostic Test
   Configuration
   --------------------------------------------------------------------------
   Paste your Google Apps Script Web App URL below after completing the
   setup steps in google-apps-script/Code.gs. It looks like:
     https://script.google.com/macros/s/AKfycb.../exec

   Leave it as an empty string ("") to disable Google Sheets collection —
   the test will still work fully, students will just rely on the
   "Print / Save as PDF" export instead.
   ========================================================================== */

const GOOGLE_SCRIPT_URL = "";
