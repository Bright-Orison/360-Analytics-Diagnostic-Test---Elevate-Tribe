/**
 * ============================================================================
 * Data Analytics Program — Diagnostic Test
 * Google Apps Script backend — collects results into a Google Sheet
 * ============================================================================
 *
 * SETUP INSTRUCTIONS (one-time, ~5 minutes):
 *
 * 1. Go to https://sheets.google.com and create a new blank spreadsheet.
 *    Name it something like "Diagnostic Test Results".
 *
 * 2. In the Sheet, click Extensions → Apps Script.
 *
 * 3. Delete any placeholder code in the editor and paste in this ENTIRE file.
 *
 * 4. Click the "Save" icon (or Ctrl/Cmd+S). Give the project a name if asked,
 *    e.g. "Diagnostic Test Collector".
 *
 * 5. Click "Deploy" → "New deployment".
 *      - Click the gear icon next to "Select type" and choose "Web app".
 *      - Description: "Diagnostic test intake" (optional).
 *      - Execute as: "Me (your-email@gmail.com)".
 *      - Who has access: "Anyone" (this MUST be "Anyone" — not "Anyone with
 *        Google account" — otherwise students' browsers will be blocked from
 *        submitting).
 *      - Click "Deploy".
 *
 * 6. Google will ask you to authorize the script (since it writes to your
 *    Sheet). Click "Authorize access", choose your Google account, click
 *    "Advanced" → "Go to [project name] (unsafe)" → "Allow".
 *    (This warning appears because it's your own unpublished script — it's
 *    safe since you wrote/pasted it yourself.)
 *
 * 7. Copy the "Web app URL" shown after deployment. It looks like:
 *      https://script.google.com/macros/s/AKfycb.../exec
 *
 * 8. Paste that URL into `js/config.js` in this project, as the value of
 *    GOOGLE_SCRIPT_URL. Save, commit, and push to GitHub (or re-publish).
 *
 * 9. Test it: open your published index.html, complete a test, submit, and
 *    check that a new row appears in your Google Sheet within a few seconds.
 *
 * NOTE: If you ever edit this script again after it's deployed, you must use
 * "Deploy" → "Manage deployments" → pencil/edit icon → "New version" →
 * "Deploy" for the changes to take effect. Simply saving is not enough.
 * ============================================================================
 */

const SHEET_NAME = "Responses";

// Column order in the sheet — keep this in sync with the payload sent by js/app.js
const COLUMNS = [
  "submitted_at",
  "student_name",
  "student_age",
  "student_email",
  "student_location",
  "student_grade",
  "total_correct",
  "overall_pct",
  "foundation_pct",
  "digital_pct",
  "excel_pct",
  "sql_pct",
  "python_pct",
  "powerbi_pct",
  "stats_pct",
  "excel_tier",
  "sql_tier",
  "python_tier",
  "powerbi_tier",
  "self_excel",
  "self_sql",
  "self_python",
  "self_powerbi",
  "self_stats",
  "answers_json"
];

function doPost(e) {
  try {
    const sheet = getOrCreateSheet_();
    const data = JSON.parse(e.postData.contents);

    // Format submitted_at as a readable date/time string
    const submittedAt = data.submitted_at
      ? new Date(Number(data.submitted_at))
      : new Date();
    data.submitted_at = Utilities.formatDate(
      submittedAt,
      Session.getScriptTimeZone() || "UTC",
      "yyyy-MM-dd HH:mm:ss"
    );

    // ---- Prevent duplicate submissions: if this email already has a row,
    // ---- UPDATE that row instead of adding a new one (so re-submits after a
    // ---- refresh don't create duplicate entries for the same student).
    const existingRow = data.student_email
      ? findRowByEmail_(sheet, data.student_email)
      : -1;

    const rowValues = COLUMNS.map(col => (data[col] !== undefined ? data[col] : ""));

    if (existingRow > 0) {
      sheet.getRange(existingRow, 1, 1, COLUMNS.length).setValues([rowValues]);
    } else {
      sheet.appendRow(rowValues);
    }

    return ContentService
      .createTextOutput(JSON.stringify({ result: "success" }))
      .setMimeType(ContentService.MimeType.JSON);

  } catch (err) {
    return ContentService
      .createTextOutput(JSON.stringify({ result: "error", message: String(err) }))
      .setMimeType(ContentService.MimeType.JSON);
  }
}

// Simple health-check so you can confirm the deployment works by visiting the
// Web App URL directly in a browser (it should show a small JSON message).
function doGet(e) {
  return ContentService
    .createTextOutput(JSON.stringify({ status: "ok", message: "Diagnostic test collector is live." }))
    .setMimeType(ContentService.MimeType.JSON);
}

function getOrCreateSheet_() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = ss.getSheetByName(SHEET_NAME);
  if (!sheet) {
    sheet = ss.insertSheet(SHEET_NAME);
  }
  if (sheet.getLastRow() === 0) {
    sheet.appendRow(COLUMNS);
    sheet.setFrozenRows(1);
  }
  return sheet;
}

function findRowByEmail_(sheet, email) {
  const emailCol = COLUMNS.indexOf("student_email") + 1; // 1-based
  const lastRow = sheet.getLastRow();
  if (lastRow < 2) return -1;
  const values = sheet.getRange(2, emailCol, lastRow - 1, 1).getValues();
  for (let i = 0; i < values.length; i++) {
    if (String(values[i][0]).trim().toLowerCase() === String(email).trim().toLowerCase()) {
      return i + 2; // +2 because range starts at row 2 and is 0-indexed
    }
  }
  return -1;
}
